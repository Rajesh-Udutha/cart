<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

	public function index()
	{
	    $this->load->library('session');
	    $this->load->model('Products_model');
	    $productData = $this->Products_model->getAllProducts();
	    $data['productData'] = $productData;
	    $data['orderData'] = $this->Products_model->getOrderData();

		if($this->session->userdata('customerid'))
		{
		    $customerid = $this->session->userdata('customerid');
		}
		else if($this->session->userdata('userid'))
		{
		    $customerid = $this->session->userdata('userid');
		}
		else {
		    $customerid = mt_rand(100000,999999);
		    $this->session->set_userdata('customerid',$customerid);
		}
		
		$orderData = $this->db->get_where('orders',array('userid'=>$customerid));
		$data['orderData'] = $orderData->result();
		
		$this->load->view('cart/index',$data);
	}
	
	public function addCart()
	{
	    $this->load->library('session');
	    if($this->input->post('productid'))
	    {
	        $totalAmount = 0;
	        $productid = $this->input->post('productid');
	        if($this->session->userdata('customerid'))
	        {
	            $customerid = $this->session->userdata('customerid');
	        }
	        else if($this->session->userdata('userid'))
	        {
	            $customerid = $this->session->userdata('userid');
	        }
	        else {
	            $customerid = mt_rand(100000,999999);
	            $this->session->set_userdata('customerid',$customerid);
	        }
	        
	        $productInfo = $this->db->get_where('productinfo',array('Id'=>$productid));
	        
	        if($productInfo->num_rows() > 0)
	        {
	            $productRow = $productInfo->row();
	            $totalAmount = $productRow->price;
	        }
	        
	        $this->db->from('orders');
	        $this->db->where('userid',$customerid);
	        $this->db->where('ProductId',$productid);
	     
	        $orderdata = $this->db->get();
	        
	        if($orderdata->num_rows() > 0)
	        {
	            $orderrow = $orderdata->row();
	            $orderquantity = $orderrow->Quantity;
	            $totalQuantity = $orderquantity + 1;
	            $finalAmount = $totalAmount+$orderrow->Price;
	            $updateData = array(
	                //        'InvId'=>$invid,
	                'Price'=>number_format($finalAmount,2),
	                'Quantity'=>$totalQuantity,
	                'date'=>date('Y-m-d'),
	           //     'ModifiedBy'=>$customerid
	            );
	            $this->db->where('userid',$customerid);
	            $this->db->where('ProductId',$productid);
	            $this->db->update('orders',$updateData);
	        }
	        else {
	            
	            $orderInfoData = array(
	                
	                //  'InvId'=>$invid,
	              //  'RestaurantID'=>$restaurantid,
	                'ProductId'=>$productid,
	                'UserId'=>$customerid,
	                'Price'=>$totalAmount,
	                'Quantity'=>'1',
	                'date'=>date('Y-m-d'),
	        //        'CreatedBy'=>$customerid,
	               
	            );
	            
	            $this->db->insert('orders',$orderInfoData);
	        }
	        
	        
	        
	        $orderData = $this->db->get_where('orders',array('userid'=>$customerid));
	        $data['orderData'] = $orderData->result();
	        $this->load->view('cart/checkcart',$data);
	    }
	}
}
