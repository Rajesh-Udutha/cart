<br>
<div class="row">
<div class="col-lg-12">
My Orders
</div>


</div>
<br>
<div class="row">
<div class="col-lg-12">
<table border="0" class="table">
	<thead>
    <tr>
    	<th>Name</th>
    	<th>Quantity</th>
    	<th>Price</th>
    	
    </tr>	
    </thead>
    <tbody>
   	<?php 
   	$totalAmount = 0;
   	if(count($orderData)>0){
   	
   	    foreach($orderData as $pdata2)
       	    {
       	        $name = '';
       	        $productInfo = $this->db->get_where('productinfo',array('Id'=>$pdata2->ProductId));
       	        
       	        if($productInfo->num_rows() > 0)
       	        {
       	            $productRow = $productInfo->row();
       	            $name = $productRow->name;
       	        }
       	        
       	    ?>
        	<tr>
				<td><?php echo $name?></td>
				<td><?php echo $pdata2->Quantity?></td>
			
				<td>RS. <?php echo number_format($pdata2->Price,2)?></td>        
		
        	</tr>
        	<?php 
        	$totalAmount = $totalAmount+$pdata2->Price;
       	    }
   	    }?>
   	    
   	    <tr>
   	    <td colspan="3"></td>
   	    </tr>
   	    <tr>
   	    <td></td>
   	    <td>Total Amount</td>
   	    <td>RS. <?php echo number_format($totalAmount,2)?></td>
   	    </tr>
    </tbody>
</table>
</div>
</div>
<div class="row">
<div class="col-lg-4">
</div>
<div class="col-lg-4">
<button type="button" class="btn btn-success">Check Out</button>
</div>
<div class="col-lg-4">
</div>
</div>