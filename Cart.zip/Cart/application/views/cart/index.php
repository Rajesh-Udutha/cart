<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
<script   src="https://code.jquery.com/jquery-3.4.1.js"  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="  crossorigin="anonymous"></script>

<style>
.table
{
    border-collapse:collapse;
}
.table td 
{
    padding:20px
}
.table th
{
    padding:4px
}
.row
{
    margin-right:0px;
    margin-left:0px
}
</style>

<div class="row">
<div class="col-lg-8">
<table border="0" class="table">
	<thead>
    <tr>
    	<th>Name</th>
    	<th>Image</th>
    	<th>Price</th>
    	<th>Action</th>
    </tr>	
    </thead>
    <tbody>
   	<?php if(count($productData)>0){
   	
       	    foreach($productData as $pdata)
       	    {
       	    ?>
        	<tr>
				<td><?php echo $pdata->name?></td>
				<td><img src="<?php echo base_url().$pdata->image?>" style="width:100px;height:100px"/></td>
				<td>RS. <?php echo number_format($pdata->price,2)?></td>        
				<td><button type="button" name="" id="" class="btn btn-success" style="padding:6px;font-size:12px " onclick="addCart('<?php echo $pdata->Id?>')">Add to Cart</button></td>	
        	</tr>
        	<?php 
       	    }
   	    }?>
    </tbody>
</table>
</div>
<div class="col-lg-4" id="cart-dv">
<?php $this->load->view('cart/checkcart',$orderData)?>
</div>
</div>
<input type="hidden" name="baseurl" id="baseurl" value="<?php echo base_url();?>" />
<script type="text/javascript">

function addCart(pid)
{
	var url = document.getElementById('baseurl').value;
	$.ajax({
		'type':'POST',
	    'url':url+'Cart/addCart',
         'data': 
         {
           'productid':pid
         },
         'beforeSend':function(){
				
		
				}, 
         'success':function(data)
         {
           $("#cart-dv").html(data)
     
         }

				});
}

</script>