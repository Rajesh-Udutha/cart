<?php 
class Products_model extends CI_Model
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    
    public function getAllProducts()
    {
        $this->db->from('productinfo');
        return $this->db->get()->result();
    }
    
    public function getOrderData()
    {
        
    }
}